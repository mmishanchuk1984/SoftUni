from project.card.card import Card


class TrapCard(Card):
    def __init__(self, username):
        super().__init__(username, damage_points=120, health_points=5)

