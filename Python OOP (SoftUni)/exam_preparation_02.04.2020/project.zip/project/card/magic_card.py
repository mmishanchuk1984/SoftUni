from project.card.card import Card


class MagicCard(Card):
    def __init__(self, username):
        super().__init__(username, damage_points=5, health_points=80)
