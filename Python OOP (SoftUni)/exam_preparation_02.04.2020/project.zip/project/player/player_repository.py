class PlayerRepository:
    def __init__(self):
        self.count = 0
        self.players = []

    def add(self, player):
        if player in self.players:
            raise ValueError(f"Player {player.username} already exists!")
        else:
            self.players.append(player)
            self.count += 1

    def remove(self, player):
        if player == "":
            raise ValueError("Player cannot be an empty string!")
        self.count -= 1
        self.players.remove(player)

    def find(self, name):
        for player in self.players:
            if player.username == name:
                return player

