from project.people.child import Child
from project.rooms.young_couple import YoungCouple
from project.rooms.young_couple_with_children import YoungCoupleWithChildren


class Everland:

    def __init__(self):
        self.rooms = []

    def add_room(self, room):
        self.rooms.append(room)

    def get_monthly_consumptions(self):
        total = 0
        for r in self.rooms:
            total += r.expenses + r.room_cost
        return f"Monthly consumption: {total}$."

    def pay(self):
        result = []
        for r in self.rooms:
            if r.budget >= (r.expenses + r.room_cost):
                r.budget -= (r.expenses + r.room_cost)
                result.append(f"{r.family_name} paid {(r.expenses + r.room_cost):.2f}$ and have {r.budget}$ left.")
            self.rooms.remove(r)
            result.append(f"{r.family_name} does not have enough budget and must leave the hotel.")
            return "\n".join(result)

    def status(self):
        result = ""
        result += f"Total population: {sum([r.members_count for r in self.rooms])}\n"
        for room in self.rooms:
            result += f"{room.family_name} with {room.members_count} members. Budget: {room.budget:.2f}$, " \
                      f"Expenses: {room.expenses:.2f}$\n"
            if room.children:
                counter = 0
                for c in room.children:
                    counter += 1
                    result += f"--- Child {counter} monthly cost: {c.cost * 30:.2f}$\n"
            if hasattr(room, "appliance"):
                app_expences = 0
                for a in room.appliance:
                    app_expences += a.expenses
                result += f"--- Appliances monthly cost: {app_expences:.2f}$\n"
        return result


everland = Everland()

young_couple = YoungCouple("Johnsons", 150, 205)

child1 = Child(5, 1, 2, 1)
child2 = Child(3, 2)
young_couple_with_children = YoungCoupleWithChildren("Peterson", 600, 520, child1, child2)

everland.add_room(young_couple)
everland.add_room(young_couple_with_children)

print(everland.get_monthly_consumptions())
print(everland.pay())
print(everland.status())

