from project.worker import Worker
from project.cheetah import Cheetah
from project.keeper import Keeper
from project.lion import Lion
from project.tiger import Tiger
from project.vet import Vet
from project.caretaker import Caretaker


class Zoo:
    def __init__(self, name, budget, animal_capacity, workers_capacity):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.animals = []
        self.workers = []

    def add_animal(self, animal, price):
        if price <= self.__budget and self.__animal_capacity > len(self.animals):
            self.animals.append(animal)
            self.__budget -= price
            return f"{animal.name} the {animal.__class__.__name__} added to the zoo"
        elif price > self.__budget:
            return "Not enough budget"
        elif self.__animal_capacity == len(self.animals):
            return "Not enough space for animal"

    def hire_worker(self, worker):
        if len(self.workers) < self.__workers_capacity:
            self.workers.append(worker)
            return f"{worker.name} the {worker.__class__.__name__} hired successfully"
        return "Not enough space for worker"

    def fire_worker(self, worker_name):
        for i in self.workers:
            if worker_name == i.name:
                self.workers.remove(i)
                return f"{worker_name} fired successfully"
        return f"There is no {worker_name} in the zoo"

    def pay_workers(self):
        total_workers_salary = sum([worker.salary for worker in self.workers])
        if total_workers_salary < self.__budget:
            self.__budget -= total_workers_salary
            return f"You payed your workers. They are happy. Budget left: {self.__budget}"
        return "You have no budget to pay your workers. They are unhappy"

    def tend_animals(self):
        total_money_for_care_animals = sum([animal.money_for_care for animal in self.animals])
        if total_money_for_care_animals > self.__budget:
            return "You have no budget to tend the animals. They are unhappy."
        else:
            self.__budget -= total_money_for_care_animals
            return f"You tended all the animals. They are happy. Budget left: {self.__budget}"

    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        lions = [repr(i) for i in self.animals if type(i) == Lion]
        tigers = [repr(i) for i in self.animals if type(i) == Tiger]
        cheetahs = [repr(i) for i in self.animals if type(i) == Cheetah]

        new_line = "\n"

        to_print = f"You have {len(self.animals)} animals{new_line}"
        to_print += f"----- {len(lions)} Lions:{new_line}"
        to_print += f"{new_line.join(lions)}{new_line}"
        to_print += f"----- {len(tigers)} Tigers:{new_line}"
        to_print += f"{new_line.join(tigers)}{new_line}"
        to_print += f"----- {len(cheetahs)} Cheetahs:{new_line}"
        to_print += f"{new_line.join(cheetahs)}"

        return to_print

    def workers_status(self):
        vets = [repr(i) for i in self.workers if type(i) == Vet]
        keepers = [repr(i) for i in self.workers if type(i) == Keeper]
        caretakers = [repr(i) for i in self.workers if type(i) == Caretaker]

        new_line = "\n"

        to_print = f"You have {len(self.workers)} workers{new_line}"
        to_print += f"----- {len(keepers)} Keepers:{new_line}"
        to_print += f"{new_line.join(keepers)}{new_line}"
        to_print += f"----- {len(caretakers)} Caretakers:{new_line}"
        to_print += f"{new_line.join(caretakers)}{new_line}"
        to_print += f"----- {len(vets)} Vets:{new_line}"
        to_print += f"{new_line.join(vets)}"

        return to_print
