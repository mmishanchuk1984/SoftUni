class Player:
    def __init__(self, name, sprint, dribble, passing, shooting):
        self.__name = name
        self.__sprint = sprint
        self.__dribble = dribble
        self.__passing = passing
        self.__shooting = shooting

    @property
    def name(self):
        return self.__name

    def __str__(self):
        new_line = "\n"
        return f"Player: {self.__name}{new_line}\
Sprint: {self.__sprint}{new_line}\
Dribble: {self.__dribble}{new_line}\
Passing: {self.__passing}{new_line}\
Shooting: {self.__shooting}"


