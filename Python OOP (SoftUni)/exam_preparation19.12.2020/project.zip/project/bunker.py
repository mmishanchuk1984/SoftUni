class Bunker:
    def __init__(self):
        self.survivors = []
        self.supplies = []
        self.medicine = []

    @property
    def food(self, products):
        food = [el for el in products if el.__class__.__name__ == "FoodSupply"]
        if not food:
            raise IndexError("There are no food supplies left!")

    @property
    def water(self, products):
        food = [el for el in products if el.__class__.__name__ == "WaterSupply"]
        if not food:
            raise IndexError("There are no water supplies left!")

    @property
    def painkillers(self, products):
        food = [el for el in products if el.__class__.__name__ == "Painkiller"]
        if not food:
            raise IndexError("There are no painkillers left!")

    @property
    def salves(self, products):
        food = [el for el in products if el.__class__.__name__ == "Salve"]
        if not food:
            raise IndexError("There are no salves left!")

    def add_survivor(self, survivor):
        if survivor in self.survivors:
            raise ValueError(f"Survivor with name {survivor.name} already exists.")
        else:
            self.survivors.append(survivor)

    def add_supply(self, supply):
        self.supplies.append(supply)

    def add_medicine(self, medicine):
        self.medicine.append(medicine)

    def heal(self, survivor, medicine_type):
        last_medicine = [m for m in self.medicine if m.__class__.__name__ == medicine_type][-1]
        if survivor.needs_healing:
            last_medicine.apply(survivor)
            self.medicine.remove(last_medicine)
            return f"{survivor.name} healed successfully with {medicine_type}"

    def sustain(self, survivor, sustain_type):
        last_supply = [s for s in self.supplies if s.__class__.__name__ == sustain_type][-1]
        if survivor.needs_sustenance:
            last_supply.apply(survivor)
            self.medicine.remove(last_supply)
            return f"{survivor.name} sustained successfully with {sustain_type}"

    def next_day(self):
        for survivor in self.survivors:
            survivor.needs -= survivor.age * 2
            self.sustain(survivor, "FoodSupply")
            self.sustain(survivor, "WaterSupply")










