from unittest import TestCase
from project.factory.paint_factory import PaintFactory


class TestPainFactory(TestCase):
    def setUp(self):
        self.factory = PaintFactory(name="Raduga", capacity=10)

    def test_init(self):
        self.assertEqual("Raduga", self.factory.name)
        self.assertEqual(10, self.factory.capacity)
        self.assertEqual(["white", "yellow", "blue", "green", "red"], self.factory.valid_ingredients)
        self.assertEqual({}, self.factory.ingredients)

    def test_add_ingredient_successful(self):
        self.factory.ingredients = {}
        result = {"white": 5}
        self.factory.add_ingredient("white", 5)
        self.assertEqual(result, self.factory.ingredients)

    def test_no_capacity_for_new_ingredient(self):
        with self.assertRaises(ValueError) as ex:
            self.factory.add_ingredient("white", 15)
            self.assertEqual("Not enough space in factory", str(ex.exception))

    def test_add_not_allowed_ingredient(self):
        with self.assertRaises(TypeError) as ex:
            self.factory.add_ingredient("rose", 1)
            self.assertEqual(f"Ingredient of type rose not allowed in Raduga", str(ex.exception))

    def test_remove_big_amonth_of_ingredient(self):
        self.factory.ingredients = {"white": 5, "green": 3}
        with self.assertRaises(ValueError) as ex:
            self.factory.remove_ingredient("green", 10)
            self.assertEqual("Ingredients quantity cannot be less than zero", str(ex.exception))

    def test_remove_not_existing_ingredient(self):
        self.factory.ingredients = {"white": 5, "green": 3}
        with self.assertRaises(KeyError) as ex:
            self.factory.remove_ingredient("magenta", 1)
            self.assertEqual("No such ingredient in the factory", str(ex.exception))

    def test_remove_ingredient_successful(self):
        self.factory.ingredients = {"white": 5, "green": 3}
        self.factory.remove_ingredient("green", 1)
        result = {"white": 5, "green": 2}
        self.assertEqual(result, self.factory.ingredients)




